
import os
from dotenv import load_dotenv
from langchain_openai import OpenAIEmbeddings
from config import EMBEDDING_MODEL_NAME

# Load .env variables into environment
load_dotenv()

def get_embedding_model() -> OpenAIEmbeddings:
    """
    Loads and returns the configured embedding model.
    Currently uses OpenAI's 'text-embedding-3-small' via API.
    """
    return OpenAIEmbeddings(
        model=EMBEDDING_MODEL_NAME,
        openai_api_key=os.getenv("OPENAI_API_KEY")  # ✅ extra seguro
    )